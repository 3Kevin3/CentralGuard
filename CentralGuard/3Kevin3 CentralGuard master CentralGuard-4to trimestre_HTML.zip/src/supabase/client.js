import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY 

if (!supabaseUrl || !supabaseKey) {
  console.error("Faltan las variables de entorno de Supabase en el archivo .env")
}

export const supabase = createClient(supabaseUrl, supabaseKey)