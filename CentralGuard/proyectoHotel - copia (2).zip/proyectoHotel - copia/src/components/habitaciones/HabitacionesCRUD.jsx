import { useEffect, useState } from 'react'

const API_URL = 'http://localhost:3001/habitaciones'
const formularioInicial = { nombre: '', precio: '', estado: 'Disponible' }

function HabitacionesCRUD() {
  const [habitaciones, setHabitaciones] = useState([])
  const [formulario, setFormulario] = useState(formularioInicial)
  const [editandoId, setEditandoId] = useState(null)
  const [mostrarFormulario, setMostrarFormulario] = useState(false)
  const [error, setError] = useState('')

  const cargarHabitaciones = async () => {
    try {
      const respuesta = await fetch(API_URL)
      if (!respuesta.ok) throw new Error('No fue posible cargar las habitaciones')
      const datos = await respuesta.json()
      setHabitaciones(datos)
    } catch (err) {
      setError(err.message)
    }
  }

  useEffect(() => {
    cargarHabitaciones()
  }, [])

  const manejarCambio = (e) => {
    setFormulario({ ...formulario, [e.target.name]: e.target.value })
  }

  const abrirNuevo = () => {
    setEditandoId(null)
    setFormulario(formularioInicial)
    setMostrarFormulario(true)
  }

  const editarHabitacion = (habitacion) => {
    setEditandoId(habitacion.id)
    setFormulario({
      nombre: habitacion.nombre ?? '',
      precio: habitacion.precio ?? '',
      estado: habitacion.estado ?? 'Disponible',
    })
    setMostrarFormulario(true)
  }

  const guardarHabitacion = async (e) => {
    e.preventDefault()
    setError('')

    const metodo = editandoId ? 'PATCH' : 'POST'
    const url = editandoId ? `${API_URL}/${editandoId}` : API_URL

    try {
      const respuesta = await fetch(url, {
        method: metodo,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formulario),
      })

      if (!respuesta.ok) throw new Error('No fue posible guardar la habitación')

      setFormulario(formularioInicial)
      setEditandoId(null)
      setMostrarFormulario(false)
      cargarHabitaciones()
    } catch (err) {
      setError(err.message)
    }
  }

  const eliminarHabitacion = async (id) => {
    try {
      const respuesta = await fetch(`${API_URL}/${id}`, { method: 'DELETE' })
      if (!respuesta.ok) throw new Error('No fue posible eliminar la habitación')
      cargarHabitaciones()
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <section className="admin-panel">
      <div className="admin-panel-header">
        <div>
          <p className="admin-label">GESTIÓN</p>
          <h2>Habitaciones</h2>
        </div>

        <button className="btn btn-gold" onClick={abrirNuevo}>
          <i className="bi bi-plus-lg"></i> Nueva habitación
        </button>
      </div>

      {mostrarFormulario && (
        <form className="room-form" onSubmit={guardarHabitacion}>
          <input
            name="nombre"
            placeholder="Nombre de la habitación"
            value={formulario.nombre}
            onChange={manejarCambio}
            required
          />
          <input
            name="precio"
            placeholder="Precio"
            value={formulario.precio}
            onChange={manejarCambio}
            required
          />
          <select name="estado" value={formulario.estado} onChange={manejarCambio}>
            <option>Disponible</option>
            <option>Ocupada</option>
            <option>Mantenimiento</option>
          </select>
          <button className="btn btn-gold" type="submit">
            {editandoId ? 'Actualizar' : 'Guardar'}
          </button>
          <button className="btn room-cancel" type="button" onClick={() => setMostrarFormulario(false)}>
            Cancelar
          </button>
        </form>
      )}

      {error && <p className="crud-error">{error}</p>}

      <div className="table-responsive">
        <table className="table admin-table">
          <thead>
            <tr>
              <th>Habitación</th>
              <th>Precio</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {habitaciones.length === 0 ? (
              <tr>
                <td colSpan="4" className="admin-empty">No hay habitaciones registradas.</td>
              </tr>
            ) : (
              habitaciones.map((habitacion) => (
                <tr key={habitacion.id}>
                  <td>{habitacion.nombre}</td>
                  <td>{habitacion.precio}</td>
                  <td><span className="room-status">{habitacion.estado ?? 'Disponible'}</span></td>
                  <td className="room-actions">
                    <button onClick={() => editarHabitacion(habitacion)} title="Editar">
                      <i className="bi bi-pencil-square"></i>
                    </button>
                    <button onClick={() => eliminarHabitacion(habitacion.id)} title="Eliminar">
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  )
}

export default HabitacionesCRUD
