import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'
import HabitacionesCRUD from '../habitaciones/HabitacionesCRUD'
import Reservas from '../reservas/Reservas'
import '../../dashboard.css'

const configuracion = {
  admin: {
    titulo: 'Administrador',
    descripcion: 'Gestiona la operación de Brisa Hotel desde un solo lugar.',
    menu: ['Inicio', 'Habitaciones', 'Reservas', 'Usuarios'],
  },
  empleado: {
    titulo: 'Empleado',
    descripcion: 'Consulta habitaciones y gestiona las reservas del hotel.',
    menu: ['Inicio', 'Habitaciones', 'Reservas'],
  },
  cliente: {
    titulo: 'Cliente',
    descripcion: 'Consulta tu información y las opciones disponibles en Brisa Hotel.',
    menu: ['Inicio', 'Habitaciones', 'Mis reservas'],
  },
}

const iconos = {
  Inicio: 'bi-grid',
  Habitaciones: 'bi-door-open',
  Reservas: 'bi-calendar-check',
  'Mis reservas': 'bi-calendar-check',
  Usuarios: 'bi-people',
}

function Dashboard() {
  const { usuario, rol, cerrarSesion } = useAuth()
  const navigate = useNavigate()
  const [seccion , setSeccion] = useState('inicio')
  const perfil = configuracion[rol] ?? configuracion.cliente
  const nombre = usuario?.user_metadata?.nombre || perfil.titulo

  const salir = async () => {
    await cerrarSesion()
    navigate('/')
  }

  return (
    <div className="admin-dashboard">
      <aside className="admin-sidebar">
        <div className="admin-brand">
          <span>BRISA</span>
          <small>HOTEL</small>
        </div>

        <nav className="admin-menu">
          {perfil.menu.map((opcion) => (
            <a href="#" 
            key={opcion}
            className={
              seccion === String(opcion).toLowerCase() ? 'active' : ''} 
              onClick={(e) =>{
                e.preventDefault()
                setSeccion(String(opcion).toLowerCase())  
              }}
              >
              <i className={`bi ${iconos[opcion]}`}></i>
              <span>{opcion}</span>
            </a>
          ))}
        </nav>

        <button className="admin-logout" onClick={salir}>
          <i className="bi bi-box-arrow-left"></i>
          Cerrar sesión
        </button>
      </aside>

      <main className="admin-content">
        <header className="admin-header">
          <div>
            <p className="admin-label">PANEL {rol.toUpperCase()}</p>
            <h1>Bienvenido, {nombre}</h1>
            <p>{perfil.descripcion}</p>
          </div>

          <div className="admin-user">
            <i className="bi bi-person-circle"></i>
            <div>
              <strong>{perfil.titulo}</strong>
              <small>{usuario?.email}</small>
            </div>
          </div>
        </header>

        <section className="admin-cards">
          <div className="admin-card">
            <div className="admin-card-icon"><i className="bi bi-door-open"></i></div>
            <div><span>Habitaciones</span><strong>Hotel</strong></div>
          </div>
          <div className="admin-card">
            <div className="admin-card-icon"><i className="bi bi-calendar-check"></i></div>
            <div><span>Reservas</span><strong>{rol === 'cliente' ? 'Mías' : 'Gestión'}</strong></div>
          </div>
          <div className="admin-card">
            <div className="admin-card-icon"><i className="bi bi-person-badge"></i></div>
            <div><span>Rol</span><strong>{perfil.titulo}</strong></div>
          </div>
        </section>

        {seccion === 'habitaciones' && (
          <>
        {(rol === 'admin' || rol === 'empleado') ? (
          <HabitacionesCRUD />
        ) : (
          <section className="admin-panel">
            <p className="admin-label">MI CUENTA</p>
            <h2>Bienvenido a Brisa Hotel</h2>
            <p>Como cliente puedes consultar habitaciones y gestionar tus reservas.</p>
          </section>
        )}
      </>
        )}

        {(seccion === 'reservas' || seccion === 'mis reservas') && (
          <Reservas />
        )}
        </main>
    </div>
  )
}

export default Dashboard
