import { useEffect, useState } from 'react'
import { useAuth } from '../../context/AuthContext'

const API_URL = 'http://localhost:3001/reservas'
const formularioInicial = {
  habitacion: '', clienteEmail: '', fechaEntrada: '',
  fechaSalida: '', estado: 'Confirmada'
}

function Reservas() {
  const { usuario, rol } = useAuth()
  const [reservas, setReservas] = useState([])
  const [formulario, setFormulario] = useState(formularioInicial)
  const [editandoId, setEditandoId] = useState(null)
  const [mostrarFormulario, setMostrarFormulario] = useState(false)
  const [error, setError] = useState('')

  const cargarReservas = async () => {
    try {
      const respuesta = await fetch(API_URL)
      if (!respuesta.ok) throw new Error('No fue posible cargar las reservas')
      const datos = await respuesta.json()

      if (rol === 'cliente') {
        setReservas(datos.filter((reserva) => reserva.clienteEmail === usuario?.email))
      } else {
        setReservas(datos)
      }
    } catch (err) {
      setError(err.message)
    }
  }

  useEffect(() => {
    cargarReservas()
  }, [rol, usuario?.email])

  const manejarCambio = (e) => {
    setFormulario({ ...formulario, [e.target.name]: e.target.value })
  }

  const abrirNuevo = () => {
    setEditandoId(null)
    setFormulario({
      ...formularioInicial,
      clienteEmail: rol === 'cliente' ? usuario?.email : '',
    })
    setMostrarFormulario(true)
  }

  const editarReserva = (reserva) => {
    setEditandoId(reserva.id)
    setFormulario({
      habitacion: reserva.habitacion ?? '',
      clienteEmail: reserva.clienteEmail ?? '',
      fechaEntrada: reserva.fechaEntrada ?? '',
      fechaSalida: reserva.fechaSalida ?? '',
      estado: reserva.estado ?? 'Confirmada',
    })
    setMostrarFormulario(true)
  }

  const guardarReserva = async (e) => {
    e.preventDefault()
    setError('')
    const metodo = editandoId ? 'PATCH' : 'POST'
    const url = editandoId ? `${API_URL}/${editandoId}` : API_URL

    try {
      const respuesta = await fetch(url, {
        method: metodo,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formulario),
      })
      if (!respuesta.ok) throw new Error('No fue posible guardar la reserva')

      setFormulario(formularioInicial)
      setEditandoId(null)
      setMostrarFormulario(false)
      cargarReservas()
    } catch (err) {
      setError(err.message)
    }
  }

  const eliminarReserva = async (id) => {
    try {
      const respuesta = await fetch(`${API_URL}/${id}`, { method: 'DELETE' })
      if (!respuesta.ok) throw new Error('No fue posible eliminar la reserva')
      cargarReservas()
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <section className="admin-panel">
      <div className="admin-panel-header">
        <div>
          <p className="admin-label">{rol === 'cliente' ? 'MI CUENTA' : 'GESTIÓN'}</p>
          <h2>{rol === 'cliente' ? 'Mis reservas' : 'Reservas'}</h2>
        </div>
        <button className="btn btn-gold" onClick={abrirNuevo}>
          <i className="bi bi-plus-lg"></i> Nueva reserva
        </button>
      </div>

      {mostrarFormulario && (
        <form className="room-form" onSubmit={guardarReserva}>
          <input name="habitacion" placeholder="Habitación"
            value={formulario.habitacion} onChange={manejarCambio} required />
          <input name="clienteEmail" placeholder="Correo del cliente"
            value={formulario.clienteEmail} onChange={manejarCambio}
            disabled={rol === 'cliente'} required />
          <input type="date" name="fechaEntrada"
            value={formulario.fechaEntrada} onChange={manejarCambio} required />
          <input type="date" name="fechaSalida"
            value={formulario.fechaSalida} onChange={manejarCambio} required />
          <select name="estado" value={formulario.estado} onChange={manejarCambio}>
            <option>Confirmada</option>
            <option>Pendiente</option>
            <option>Cancelada</option>
          </select>
          <button className="btn btn-gold" type="submit">
            {editandoId ? 'Actualizar' : 'Guardar'}
          </button>
          <button className="btn room-cancel" type="button"
            onClick={() => setMostrarFormulario(false)}>
            Cancelar
          </button>
        </form>
      )}

      {error && <p className="crud-error">{error}</p>}

      <div className="table-responsive">
        <table className="table admin-table">
          <thead>
            <tr>
              <th>Habitación</th><th>Cliente</th><th>Entrada</th>
              <th>Salida</th><th>Estado</th><th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {reservas.length === 0 ? (
              <tr><td colSpan="6" className="admin-empty">No hay reservas registradas.</td></tr>
            ) : (
              reservas.map((reserva) => (
                <tr key={reserva.id}>
                  <td>{reserva.habitacion}</td>
                  <td>{reserva.clienteEmail}</td>
                  <td>{reserva.fechaEntrada}</td>
                  <td>{reserva.fechaSalida}</td>
                  <td><span className="room-status">{reserva.estado}</span></td>
                  <td className="room-actions">
                    <button onClick={() => editarReserva(reserva)} title="Editar">
                      <i className="bi bi-pencil-square"></i>
                    </button>
                    <button onClick={() => eliminarReserva(reserva.id)} title="Eliminar">
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  )
}
export default Reservas
