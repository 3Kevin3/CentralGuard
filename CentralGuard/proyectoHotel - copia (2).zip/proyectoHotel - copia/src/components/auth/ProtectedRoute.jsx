import { Navigate } from 'react-router-dom'
import { useAuth } from '../../context/AuthContext'

function ProtectedRoute({ children }) {
  const { usuario, cargando } = useAuth()

  if (cargando) {
    return <div className="auth-loading">Cargando sesión...</div>
  }

  if (!usuario) {
    return <Navigate to="/" replace />
  }

  return children
}

export default ProtectedRoute