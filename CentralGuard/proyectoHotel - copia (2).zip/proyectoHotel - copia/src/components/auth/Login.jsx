import { useState } from 'react'
import { supabase } from '../../services/supabase'
import { useNavigate } from 'react-router-dom'

function Login() {
    const [email, setEmail] = useState('')
    const [password ,setPassword] = useState('')
    const [mensaje , setMensaje] = useState('')

    const navigate = useNavigate()

    const iniciarSesion = async (e) =>{
        e.preventDefault()

        const {data, error } = await supabase.auth.signInWithPassword({
            email, 
            password
        })

        if (error) {
            setMensaje('Correo o contraseña invalidas')
            return
        }

        console.log('Sesion', data.session)
        console.log('JWT', data.session.access_token)
        console.log('Usuario', data.user)
        console.log('Correo', data.user.email)
        console.log('Rol', data.user.user_metadata.rol)

        const rol = data.user.user_metadata.rol

            setMensaje('Inicio exitoso')
            navigate('/dashboard')

    }
return (
    <>
            
        <h2>Iniciar sesión </h2>
        <p>Accede a tu cuenta del Hotel</p>
        <form onSubmit={iniciarSesion} action="">
            
            <input type="email"
            placeholder="Correo Electronico"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            />

            <input type="password"
            placeholder="Contraseña"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            />
            
            <button type="submit">
                Ingresar
            </button>
{mensaje &&  <p>{mensaje}</p>}

        </form>
        </>
    
)

}

export default Login